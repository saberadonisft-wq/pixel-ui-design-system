Pixel Forge Engine Bundle — hero-frost-archmage
================================================
1. Godot 4.x: Copy this folder into res://assets/ and assign forge-sprites.godot.tres to AnimatedSprite2D.
   Attach forge-atlas-normal.png + forge-atlas-emissive.png inside a CanvasTexture for 2.5D lighting.
2. Unity 6 (URP 2D): Import forge-atlas-diffuse.png (Filter Mode: Point, Compression: None, PPU: 16)
   and bind Secondary Textures (_NormalMap, _EmissiveMap) per forge-atlas.unity.json.
3. Aseprite / TexturePacker: Open forge-atlas-diffuse.png with forge-atlas.aseprite.json.
4. Modular Paper-Doll: Concentric 64x64 + 96x96 layers are in layers/ and runtime tint masks in masks/.
